__name__ = 'pythonhost'
__website__ = 'https://pythonhost.ir'
__author__ = 'dapishro Co'
__version__ = '1.0.5'
__license__ = 'MIT'

from pythonhost.pythonhost import *
