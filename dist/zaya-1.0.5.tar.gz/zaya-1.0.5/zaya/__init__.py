__name__ = 'zaya'
__website__ = 'https://zaya.io'
__author__ = 'Shabakeh Sazan Tousan LLC'
__documentation__ = 'https://pypi.org/project/zaya/'
__version__ = '1.0.5'
__license__ = 'MIT'

from zaya.zaya import *
